#ifndef MOD_COMMON_H
#define MOD_COMMON_H

#include <string.h>
#include <stdio.h>

typedef enum 
{
	NONE,
	TCP_T,
	RTU_T
}ConnType;
//���ַ�����ȡ����
int getInt(const char str[], int * ok)
{
	int value;
	int ret = sscanf(str, "0x%x", &value);
	if (0 >= ret) //couldn't convert from hex, try dec
	{
		ret = sscanf(str, "%d", &value);
	}

	if (0 != ok)
	{
		*ok = (0 < ret);
	}

	return value;
}
//�����ṹ��
typedef struct  
{
	ConnType type;

	void(*del)(void * backend);

	//connon client/server functions
	int(*setParam)(void * backend, char c, char *value);
	modbus_t * (*createCtxt)(void * backend);

	//server functions
	int(*listenForConnection)(void * backend, modbus_t * ctx);
	void(*closeConnection)(void * backend);
}BackendParams;

typedef struct  
{
	BackendParams base;
	char devName[32];
	int baud;
	int dataBits;
	int stopBits;
	char parity;
}RtuBackend;                     //RTU �����ṹ��

int setRtuParam(void * backend, char c, char * value)
{
	RtuBackend * rtuParams = (RtuBackend *)backend;
	int ok = 1;

	switch (c)
	{
	case 'b':
	{
		rtuParams->baud = getInt(value, &ok);
		if (0 == ok)
		{
			printf("Baudrate is invalid %s", value);
			ok = 0;
		}
	}
	break;
	case 'd':
	{
		int db = getInt(value, &ok);
		if (0 == ok || (7 != db && 8 != db))
		{
			printf("Data bits incorrect (%s)", value);
			ok = 0;
		}
		else
			rtuParams->dataBits = db;
	}
	break;
	case 's':
	{
		int sb = getInt(value, &ok);
		if (0 == ok || (1 != sb && 2 != sb))
		{
			printf("Stop bits incorrect (%s)", value);
			ok = 0;
		}
		else
			rtuParams->stopBits = sb;
	}
	break;
	case 'p':
	{
		if (0 == strcmp(value,"none"))
		{
			rtuParams->parity = 'N';
		}
		else if (0 == strcmp(value,"even"))
		{
			rtuParams->parity = "E";
		}
		else if (0 == strcmp(value,"odd"))
		{
			rtuParams->parity = 'o';
		}
		else
		{
			printf("Unrecognized parity (%s)", value);
			ok = 0;
		}
	}
	break;
	default:
		printf("Unknown rtu param (%c: %s)\n\n", c, value);
		ok = 0;
	}

	return ok;
}

modbus_t * createRtuCtx(void * backend)
{
	RtuBackend * rtu = (RtuBackend*)backend;
	modbus_t * ctx = modbus_new_rtu(rtu->devName, rtu->baud,
		rtu->parity, rtu->dataBits, rtu->stopBits);

	return  ctx;
}
  
void delRtu(void * backend)
{
	RtuBackend * rtu = (RtuBackend *)backend;
	free(rtu);
}

int listenForRtuConnection(void * backend, modbus_t * ctx)
{
	(void)backend;
	(void)ctx;

	printf("Connceting...\r\n");
	return(0 == modbus_connect(ctx));
}
void closeRtuConnection(void * backend)
{
	(void)backend;
}

BackendParams * createRtuBackend()
{
	RtuBackend * rtu = (RtuBackend *)malloc(sizeof(RtuBackend));
	rtu->base.type = RTU_T;
	rtu->base.setParam            = &setRtuParam;
	rtu->base.createCtxt          = &createRtuCtx;
	rtu->base.listenForConnection = &listenForRtuConnection;
	rtu->base.closeConnection     = &closeRtuConnection;
	rtu->base.del                 = &delRtu;

	strcpy(rtu->devName, "");
	rtu->baud     = 9600;
	rtu->dataBits = 8;
	rtu->stopBits = 1;
	rtu->parity   = 'E'; 

	return (BackendParams *)rtu;
}

typedef struct
{
	BackendParams base;
	char ip[32];
	int port;

	int clientSocket;
}TcpBackend;      //TCP�����ṹ��

int setTcpParam(void * backend, char c, char * value)
{
	TcpBackend * tcp = (TcpBackend *)backend;
	
	int ok = 1;

	switch (c)
	{

	case'p':
	{  
		char *optarg;
		tcp->port = getInt(optarg, &ok);
		if (0 == ok)
		{
			printf("Port parameter %s is not integer!\n\n", optarg);
		}
	}
	break;

	default:
		printf("Unknown tcp param (%c %s)\n\n", c, value);
		ok = 0;
	}

	return ok;
}

modbus_t * createTcpCtx(void * backend)
{
	TcpBackend * tcp = (TcpBackend *)backend;
	modbus_t * ctx = modbus_new_tcp(tcp->ip, tcp->port);

	return ctx;
}

void delTcp(void * backend)
{
	TcpBackend * tcp = (TcpBackend *)backend;
	free(tcp);
}

int listenForTcpConnection(void * backend, modbus_t * ctx)
{
	TcpBackend * tcp = (TcpBackend *)backend;
	tcp->clientSocket = modbus_tcp_listen(ctx, 1);
	if (-1 == tcp->clientSocket)
	{
		printf("Listen return %d (%s)\n",
			tcp->clientSocket, modbus_strerror(errno));
		return 0;
	}
	modbus_tcp_accept(ctx, &(tcp->clientSocket));
	return 1;
}

void closeTcpConnection(void * backend)
{
	TcpBackend * tcp = (TcpBackend *)backend;
	if (tcp->clientSocket != -1)
	{
		close(tcp->clientSocket);
		tcp->clientSocket = -1;
	}
}

BackendParams * createTcpBackend()
{
	TcpBackend * tcp                = (TcpBackend *)malloc(sizeof(TcpBackend));
	tcp->clientSocket               = -1;
	tcp->base.setParam              = &setTcpParam;
	tcp->base.createCtxt            = &createTcpCtx;
	tcp->base.del                   = &delTcp;
	tcp->base.listenForConnection   = &listenForRtuConnection;
	tcp->base.closeConnection       = &closeTcpConnection;

	tcp->base.type                  = TCP_T;
	strcpy(tcp->ip, "0.0.0.0");
	tcp->port = 502;

	return (BackendParams *)tcp;
}

#endif //MOD_COMMON_H
